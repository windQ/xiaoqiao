<div class="w1000 contact">
		<ul class="clearfix bdsharebuttonbox" data-tag="share_1">
			<li><a href=""><img src="images/address.jpg"></a></li>
			<li><a href=""><img src="images/tel.jpg"></a></li>
			<li><a href="tencent://message/?uin=QQ号&Site=www.xiaoqiao.com&Menu=yes"><img src="images/QQ.jpg"></a></li>
			<li><a id="sina" class="bds_tsina" title="分享到新浪微博" data-cmd="tsina"></a></li>
			<li><a id="weixin" class="bds_weixin" title="分享到微信" data-cmd="weixin" href="#"></a></li>
		</ul>
	</div>