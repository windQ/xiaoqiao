<?php

class QGenerator_Exception extends QException
{
}

