<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
       "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
  <title>访问的页面不存在 (404)</title>
    <style type="text/css">
        body { background-color: #fff; color: #666; text-align: center; font-family: arial, sans-serif; }
        div.dialog {
            width: 25em;
            padding: 0 4em;
            margin: 4em auto 0 auto;
            border: 1px solid #ccc;
            border-right-color: #999;
            border-bottom-color: #999;
        }
        h1 { font-size: 100%; color: #f00; line-height: 1.5em; }
        p.tip { font-size: 12px; color: #aaa; }
    </style>
</head>

<body>
  <div class="dialog">
    <h1>访问的页面不存在</h1>
    <p>请检查是否正确输入了访问地址，或者该页面已经移除。</p>
    <p>&nbsp;</p>
    <p class="tip">修改 public/404.php 文件可以定制此出错页面的内容。</p>
  </div>
</body>
</html>